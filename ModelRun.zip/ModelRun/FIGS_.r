# Baseline behaviour (weather 2014)
# FIGURES


if (is.element(BEHAVIOUR,c(11:14))){ #Behaviour loop #############################


#FIGURE 1 - Traits
pdf(paste0("FIG_Baseline_Traits__",Behaviour[BEHAVIOUR-10],YEAR,"_",TODAY,".pdf"))


#figure settings
par(mfrow=c(3,3))
par(mar=c(4,4,3,3)-c(0.2,0,0,1)) #default: par("mar") = c(5, 4, 4, 2) + 0.1. 
par(font.lab  = 2, cex.lab=1.2)  #axes labels size (default 1), font (default 1; 2=bold)
par(oma=c(0,0.5,0.5,0))          #external (not each panel) left and top

#figure definitions
X2=""; X1="Weeks"
COL3="green"
COL4="orange"

#Curve legends
if(base=="L3"){Y0="L3/kgDM="; Y1=L30r}
if(base=="Ns"){Y0="Stock. dens.="; Y1=Nsr}
if(base=="T1"){Y0="Start treat. ="; Y1=paste0(T1r/7,"w")}
if(base=="T2"){Y0="Restart treat. ="; Y1=paste0(T2r/7,"w")}

#BW
   y1=BW1; y2=BW2; y3=BW3; YLIM=c(min(y1,y2,y3),max(y1,y2,y3))
   if(is==15){y4=BW4; YLIM=c(min(y1,y2,y3,y4),max(y1,y2,y3,y4))}
   plot(WEEKS,y1,type="l",lwd=2,col="blue",ylim=YLIM,xlab=X1,ylab="BW (kg)", main="")
   lines(WEEKS,y2,type="l",lwd=2,col="red")
   lines(WEEKS,y3,type="l",lwd=2,col=COL3)
   if(is<15) {legend("bottomright",bty="n",legend=c(paste0(Y0,Y1[1]),paste0(Y0,Y1[2]),paste0(Y0,Y1[3])),col=c("blue","red", COL3), lty=1,cex=1)} #lty=line type; cex=size
   if(is==15){lines(WEEKS,y4,type="l",lwd=2,col=COL4); 
   legend("bottomright",bty="n",legend=c(paste0(Y0,Y1[1]),paste0(Y0,Y1[2]),paste0(Y0,Y1[3]),paste0(Y0,Y1[4])),col=c("blue","red", COL3, COL4), lty=1,cex=1) }

#FEC   
   y1=FEC1; y2=FEC2; y3=FEC3;  YLIM=c(0,max(y1,y2,y3))
   if(is==15){y4=FEC4; YLIM=c(0,max(y1,y2,y3,y4))}
   plot(WEEKS,y1,type="l",lwd=2,col="blue",ylim=YLIM,xlab=X1,ylab="FEC (Eggs/g)",main="")
   lines(WEEKS,y2,type="l",lwd=2,col="red")
   lines(WEEKS,y3,type="l",lwd=2,col=COL3)
   if(is==15){lines(WEEKS,y4,type="l",lwd=2,col=COL4)}

#L3
   y1=L31/1000; y2=L32/1000; y3=L33/1000;  YLIM=c(0,max(y1,y2,y3))
   if(is==15){y4=L34/1000; YLIM=c(0,max(y1,y2,y3,y4))}
   plot(WEEKS,y1,type="l",lwd=2,col="blue",ylim=YLIM,xlab=X1,ylab="L3 herbage (/kgDM/1000)",main="")
   lines(WEEKS,y2,type="l",lwd=2,col="red")
   lines(WEEKS,y3,type="l",lwd=2,col=COL3)
   if(is==15){lines(WEEKS,y4,type="l",lwd=2,col=COL4)}

#FI
   y1=FI1; y2=FI2; y3=FI3;  YLIM=c(0,max(y1,y2,y3)*1.05)
   if(is==15){y4=FI4; YLIM=c(0,max(y1,y2,y3,y4))}
   plot(WEEKS,y1,type="l",lwd=2,col="blue",ylim=YLIM,xlab=X1,ylab="FI(kgDM/d)",main="")
   lines(WEEKS,y2,type="l",lwd=2,col="red")
   lines(WEEKS,y3,type="l",lwd=2,col=COL3)
   if(is==15){lines(WEEKS,y4,type="l",lwd=2,col=COL4)}

#W   
   y1=W1/1000; y2=W2/1000; y3=W3/1000;  YLIM=c(0,max(y1,y2,y3))
   if(is==15){y4=W4/1000; YLIM=c(0,max(y1,y2,y3,y4))}
   plot(WEEKS,y1,type="l",lwd=2,col="blue",ylim=YLIM,xlab=X1,ylab="Worms/1000",main="")
   lines(WEEKS,y2,type="l",lwd=2,col="red")
   lines(WEEKS,y3,type="l",lwd=2,col=COL3)
   if(is==15){lines(WEEKS,y4,type="l",lwd=2,col=COL4)}

#Re
   y1=Re1; y2=Re2; y3=Re3;  YLIM=log10(c(min(y1,y2,y3),max(y1,y2,y3)))
   if(is==15){y4=Re4; YLIM=log10(c(min(y1,y2,y3,y4),max(y1,y2,y3,y4)))}
   plot(WEEKS,log10(y1),type="l",lwd=2,col="blue",ylim=YLIM,xlab=X1,ylab="log10(Re)")
   lines(WEEKS,log10(y2),type="l",lwd=2,col="red")
   lines(WEEKS,log10(y3),type="l",lwd=2,col=COL3)
   if(is==15){lines(WEEKS,log10(y4),type="l",lwd=2,col=COL4)}

dev.off()




#FIGURE 2 - Weather T,RF (2014)
pdf(paste0("FIG_Baseline_Weather_",YEAR,"_",TODAY,".pdf"))

#figure settings
par(mfrow=c(2,2))
par(mar=c(4,4,3,3)-c(0.2,0,0,1)) #default: par("mar") = c(5, 4, 4, 2) + 0.1. 
par(font.lab  = 1, cex.lab=1.2)  #axes labels size (default 1), font (default 1; 2=bold)
par(oma=c(0,0.5,0.5,0))          #external (not each panel) left and top
par(font.main= 2, cex.main=1 )   #default=2
par(bty="l")                     #left-bottom box lines only #default "o" closed box

MAIN="Baseline: N Ireland 2014"
plot(tTP1114/7,Ps1114,type="l",lwd=2,xlab="Week",ylab="Rainfall (mm/d)",main=MAIN)
plot(tTP1114/7,Ts1114,type="l",lwd=2,xlab="Week",ylab="Temperature (C)",main="") 

dev.off()


}#Behaviour loop 11:14 ###########################################################




#FIGURE 3 - Beta
if (is.element(BEHAVIOUR,14)){#BEHAVIOUR 14 ######################################

pdf(paste0("FIG_Baseline_betai__",Behaviour[BEHAVIOUR-10],YEAR,"_",TODAY,".pdf"))

plot(WEEKS,1000*m2*FIDM/Gt,type="l",pch=20,lwd=3,ylab="",xlab=""); #small pts
mtext(side=2,expression(paste(beta," (1/larva/host/d) x 1000")),cex=1.5,line=2) 
mtext(side=1,"Weeks",cex=1.5,line=2);  

dev.off()
}#BEHAVIOUR 14 ###################################################################



##END