To run the model:
Open the R environment
Keep all R files in the same working directory 
Execute Main_Model.r
