##Epidemiological model of GIN infection in grazing cattle
##By J.A.N. Filipe
##Email: Joao.Filipe@bioss.ac.uk

##clear working space
rm(list=ls())

##path of current working directory
pwd <-getwd()
 
##calendar date
TODAY <- format(Sys.Date(), "%d-%m-%Y")

#function to get current date & time
tim <- function(){Sys.time()} 


#######################################################################
#BEHAVIOUR: one parameter varies in each behaviour (using the Baseline)
#######################################################################

cs <- 11:14  #set of behaviours
Behaviour <- c("L3-on-pasture","Stocking-density","Treatment-start-time","Treatment-restart-time","Climates") #names of behaviours
ta <- tim() #current time


for (is in cs){ #Behaviour loop #####################################################################

  BEHAVIOUR=is           #current behaviour
  source("Parameters.r") #Model Parameters - start or refresh to default parameters after any changes
  switch(1+is-11,        #nr=number of parameter runs
        {nr=3; base="L3";  TREAT=0; L30r = c(100,200,500)},
        {nr=3; base="Ns";  TREAT=0; Nsr  = c(1,5,7)},
        {nr=3; base="T1";  TREAT=1; T1r  = c(0,28,56)},
        {nr=3; base="T2";  TREAT=1; T2r  = c(21,35,49)});


########################
#PARAMETERS THAT CHANGE
########################
for (ir in 1:nr){ #Parameter loop ##################################################################

##Variable parameters
  if (base=="L3") {L3c0 <- L30r[ir]  }
  source("Data.r") #FL parameters and ICs
  if (base=="Ns") {Nstock   <-  Nsr[ir];  }
  if (base=="T1") {T1       <-  T1r[ir];  T2 <-  0;  Tdrug=21}
  if (base=="T2") {T2       <-  T2r[ir];  T1 <-  0;  Tdrug=21}
  if (!is.element(base,c("T1","T2"))) {TREAT=0}
  print(paste("####### L30 = ",L3c0, ", Ns = ",Nstock, ", T1 = ", T1, ", T2 = ", T2))


######################
#INITIALISATION (time i=1)
######################
##FL stages: number per hectare
   Ep     <- array(0,dim=c(nt,1)); 
   Ec     <- 0*Ep; 
   L12    <- 0*Ep; 
   L3f    <- 0*Ep; 
   L3p    <- 0*Ep; 
   L3h    <- 0*Ep; 
   L3s    <- 0*Ep;
   Ep[1]  <- INITEp;
   Ec[1]  <- INITEc;
   L12[1] <- INITL12;
   L3f[1] <- INITL3f;
   L3p[1] <- INITL3p;
   L3h[1] <- m2[1]*L3p[1]   #on herbage - input for HOST
   L3s[1] <- L3p[1]-L3h[1]  #on soil    = pasture - herbage

##HOST

##time-sequence vector
vt    <- array(0,dim=c(nt,1))

#Dosing
Idose <- vt;   #Indicator of L3 DOSE (0=none, 1=yes)

#Treatment
outT  <- vt+1; #Indicator of Out-of-treatment  (0=in treatments, 1=out)
if (TREAT==1)
   { 
   it1 = (T1/dt)
   it2 = it1 + (Tdrug/dt)
   iTREAT = it1:it2
   if(T2>T1)
      {
      it3 = (T2/dt)
      it4 = it3 + (Tdrug/dt);
      iTREAT=c(iTREAT,it3:it4)
      }
   outT[iTREAT] = 0 
   }

#Development of L3
Lt         <- array(0,c(nt,nl))
Lt[1,1:nl] <- (INITLt=array(0,c(1,nl))) #INITLt=initial L3 in host
L          <- vt
L[1]       <- Lt[1,nl]

#Development of immunity
Ct         <- array(0,c(nt,nC))
Ct[1,1:nC] <- (INITCt=array(0,c(1,nC))) #INITLt=initial cumulative exposure to L3 (nC stages )
C          <- vt
C[1]       <- Ct[1,nC]

#Immunity, INITIm
FIm    <- function(xc,im0){ i0<- im0^(1/nI); im <- (1 - (1-i0)*exp(-xc*oCm))^nI; return (im) } #Immunity level
FDIm   <- function(im,cni1,cni){ Im1 = im^(1/nI); return(dmi <- nI*Im1^(nI-1)*(omeanC*cni1-muC*cni)*(oCm)*(1-Im1))} #derivative of immunity level
Im     <- vt
DIm    <- vt
Im[1]  <- FIm(INITCt[nC],INITIm)
DIm[1] <- FDIm(Im[1],Ct[1,nC-1],Ct[1,nC]) 

#Control of parasite by host
Fest   <- function(im)  { est = est0 + (est1-est0)*im; estl = est^onl;        return(c(est,estl))} #Establishment rate
FmuW   <- function(im)  { muW = muW0 + (muW1-muW0)*im^nW;                     return(muW)}         #Worm mortality rate
Ffe    <- function(im,w){ f   = f0   + (f1-f0)*im^nf; fe = f*(Ws/(Ws+w))^0.5; return(c(f,fe))}     #Density-dependent fecundity rate
estl   <- vt
muW    <- vt
fe     <- vt
estl[1]<- Fest(Im[1])[2]
muW[1] <- FmuW(Im[1])

#Worms and egg production #Assuming: no treatment at it=1
W      <- vt
E      <- vt
Epd    <- vt
DW     <- vt
W[1]   <- INITW
E[1]   <- INITE
DW[1]  <- estl[1]*omeanL*Lt[1,nl] - muW[1]*W[1]
		
#Control of parasite II
fe[1]  <- Ffe(Im[1],W[1])[2]   
Epd[1] <- pfem*fe[1]*W[1]

#Anorexia
FAnorexia  <- function(dw,im){ IMOD=(1-im)^0.3; return(exp(lnExpq*IMOD*tanh(dw*oDWmax)))}  #Anorexia effects stop (via DW=0) when OUTT=0

#Body weight
FDmaintDry0<- function(bw){return(cMaint*bw^0.75)} #Archer 1997, Kock 1963  #Assuming neutral thermal conditions
BW         <- vt
BW[1]      <- BW0

#Feed intake per day, net and DM
Fpdry      <- function(bw){ pebw=1-0.09; pdry=1-0.707*1.9968*pebw*(bw*pebw)^(0.707-1); return(pdry)} #Proportion of BW gain that is DM  (Allometry: Williams 1992, Carstens 1991)
FAout      <- function(tim){ kg=kout; Fout=(exp(-kg*tim+aout))*(kg*tim/aout)^aout; return(exp(log(nout)*Fout)) } #FI drop at turnout
FFINetMax0 <- function(bw){ return(Bg*bw*log(BWm/bw) + FDmaintDry0(bw)/Fpdry(bw))} #Assuming neutral thermal conditions 

FFINet0    <- function(bw,dw,im,tim){ 
               Gcap0=1; a=10^(-0.936); b=1.032;  Gcap=Gcap0*a*bw^b; #Demment 1985; Clauss 2007
               return( min(Gcap, FAout(tim)*FAnorexia(dw,im)*FFINetMax0(bw)/DDM)*DDM)} #FFINet re DigesDM; Gcap and FFINetMAx/DDM re DigesDM + nonDigesDM 
FIDM       <- vt;
FaecesWt   <- vt
FEC        <- vt
FIDM[1]    <- FFINet0(BW[1],DW[1],Im[1],TIME[1])*Fpdry(BW[1])/DDM #Assuming neutral thermal conditions 
FaecesWt[1]<- FIDM[1]*(1-DDM)/pFaecesDM #WetFaeces
FEC[1]     <- (Epd[1]/FaecesWt[1]/1000) #eggs/gram-wet-faeces

#Grass density DM per ha
Gt         <- vt ;    Gtph <- vt
Gtph[1]    <- INITGtph     #kg/ha
Gt[1]      <- Gtph[1]*Area
	 
#Rate of L3 intake per day
J          <- vt; 
L3c        <- vt;    #L3/kgDM
L3csim     <- vt;
betai      <- vt;
L3c[1]     <-  L3c0
L3csim[1]  <-  L3c[1]
betai[1]   <-  m2[1]*FIDM[1]/Gt[1]  #Individual rate of infection per L3

Idose[is.element(TIME,tdose)]=1     #tdose<0 means no dose given
J[1]       <- Idose[1]*lar3 + L3c[1]*FIDM[1]

#Reproductive number, effective
Re      <- vt
FRe     <- function(egghost,cl3host,fidm,gt,eggfl,l3h,mu4i,mu5i,m2i){
           bet<-Nstock*(m2i*fidm/gt);
		   Rhost=(egghost+1)/(cl3host+1);
		   RL3hEggs =(l3h+1)/(eggfl+1);
           probIngestL3 = bet/(bet+mu4i*(1-m2i) + mu5i*m2i) 		   
		   return(Rhost*RL3hEggs*probIngestL3)}
Re[1]   <- FRe(E[1],C[1],FIDM[1],Gt[1],Ec[1],L3h[1],mu4[1],mu5[1],m2[1])


######
#TIME
######
for (i in 2:nt){#### TIME LOOP ###################################################################
##FL
   EpImin1    <- Ep[i-1]
   L12Imin1   <- L12[i-1]
   L3fImin1   <- L3f[i-1]
   L3pImin1   <- L3p[i-1]
   deltaImin1 <- delta[i-1]
   m1Imin1    <- m1[i-1]
   m2Imin1    <- m2[i-1] 
   Ein     <-  Nstock*Epd[i-1]*C0
   Ec[i]   <-  Ec[i-1]  + dt*( Ein ) ; 
   Ep[i]   <-  EpImin1  + dt*( Ein                  -  deltaImin1*EpImin1   - mu1[i-1]*EpImin1  )
   L12[i]  <-  L12Imin1 + dt*( deltaImin1*EpImin1   -  deltaImin1*L12Imin1  - mu2[i-1]*L12Imin1 )
   L3f[i]  <-  L3fImin1 + dt*( deltaImin1*L12Imin1  -     m1Imin1*L3fImin1  - mu3[i-1]*L3fImin1 )
   L3p[i]  <-  L3pImin1 + dt*( m1Imin1*L3fImin1     - (mu4[i-1]*(1-m2Imin1) + mu5[i-1]*m2Imin1)*L3pImin1 - Nstock*FIDM[i-1]*L3c[i-1] ) #Nstock*Ag*betai*L3p = H*betai*L3p ; where betai=FIDM*m2/Gt , L3p=L3c/Gt/Ag
   L3h[i]  <-  m2[i]*L3p[i]   #on herbage
   L3s[i]  <-  L3p[i]-L3h[i]  #on soil = pasture - herbage

##HOST
#Treatment
   OUTT <- outT[i]

#Development of L3 – stages of development and survival up to establishment as adults
#Lt Dynamics
   EST <- estl[i-1]
   for (j in 1:nl)
   {
           Y  <- Lt[i-1,j]
           Y0 <- if(j>1){ Lt[i-1,j-1] } else { J[i-1]/omeanL }
      Lt[i,j] <- (Y  + dt*omeanL*( EST*Y0 - Y ) )*OUTT
   }
   L[i] <- Lt[i,nl] #L5, L4, ready to become adult worms

#Development of immunity - cumulative exposure
#Ct Dynamics
   for (j in 1:nC)
   {
           r  <- if(j<nC){ 1 } else { muC/omeanC}
           Y  <- Ct[i-1,j]
           Y0 <- if(j>1) { Ct[i-1,j-1] } else { ( J[i-1]/omeanC )}
      Ct[i,j] <- Y  + dt*omeanC*( Y0 - r*Y ) 
   }
   C[i] <- Ct[i,nC] #Final stage of cumulative exposure

#Immunity 
   Im[i]   <- FIm(Ct[i,nC],INITIm) 
   Y       <- Im[i]
   estl[i] <- Fest(Y)[2]
   muW[i]  <- FmuW(Y)  

#Derivative of Im
   DIm[i]  <- FDIm(Y,Ct[i,nC-1],Ct[i,nC])


#Worms and egg production
   EST     <- estl[i-1]
   Y0      <- L[i-1]
   Y       <- W[i-1]
#Derivative of W
   DW[i]   <- (dw <- ( EST*omeanL*Y0 - muW[i-1]*Y )*OUTT )
   W[i]    <- (Y  + dt*( dw ) )*OUTT
#Eggs per day
   Y0      <- Y
   Epd[i]  <- (epd<- pfem*fe[i-1]*Y0) #Egg production stops via W - eggs not killed by drug
   E[i]    <- (E[i-1]  + dt*( epd ) )

#Control of parasite II
   fe[i]   <- Ffe(Im[i],W[i])[2]
   
##Body weight, feed intake, Anorexia
   Y          <- BW[i-1]
#Feed intake per day, Net and Wet
   DFINet     <- FFINet0(Y,DW[i-1],Im[i-1],TIME[i-1]) #Assuming neutral thermal conditions 
   Dmaintopdry<- FDmaintDry0(Y)/Fpdry(Y)	          #Assuming neutral thermal conditions 
   DImm       <- cI1*DIm[i-1] + cI2*Im[i-1]
   Ddamage    <- cw*W[i-1]
   Dinfection <- DImm + Ddamage
   BW[i]      <- Y  + dt*( DFINet - Dmaintopdry - Dinfection )
#Feed intake DM per day
   FIDDM      <- DFINet*Fpdry(Y)
   FIDM[i]    <- FIDDM/DDM;

#FEC (eggs/gram DM) via Faeces 
   FaecesWt[i]<- FIDM[i]*(1-DDM)/pFaecesDM #WetFaeces
   FEC[i]     <- (Epd[i]/FaecesWt[i]/1000) #eggs/gram-wet-faeces

#Grass density DM per hectare
   Y          <- Gt[i-1]
   Gt[i]      <- Y  + dt*( rg*Area*(1 - Y/Gm) - Nstock*FIDM[i-1]*Area )  #kgDM Grass in system of area Area
   Gtph[i]    <- Gt[i]/Area                                              #kgDM/ha

#Rate of L3 intake per day
   L3c[i]     <- (L3h[i]/Gtph[i])      #L3h (L3/ha) - calculated within the FL stage variables
   J[i]       <- Idose[i]*lar3 + L3c[i]*FIDM[i]
   betai[i]   <-  m2[i]*FIDM[i]/Gt[i]  #Individual rate of infection per L3

#Re total
   Re[i]       <- FRe(E[i],C[i],FIDM[i],Gt[i],Ec[i],L3h[i],mu4[i],mu5[i],m2[i])

}#i## TIME LOOP #####################################################################


#Variables plotted for different parameter values (same behaviour is)
X<-BW;      switch(ir,{BW1  <- X},  {BW2  <- X},  {BW3  <- X},  {BW4  <- X});
X<-FIDM;    switch(ir,{FI1  <- X},  {FI2  <- X},  {FI3  <- X},  {FI4  <- X});
X<-FEC;     switch(ir,{FEC1 <- X},  {FEC2 <- X},  {FEC3 <- X},  {FEC4 <- X});
X<-L3c;     switch(ir,{L31  <- X},  {L32  <- X},  {L33  <- X},  {L34  <- X});
X<-W;       switch(ir,{W1   <- X},  {W2   <- X},  {W3   <- X},  {W4   <- X});
X<-DW;      switch(ir,{DW1  <- X},  {DW2  <- X},  {DW3  <- X},  {DW4  <- X});
X<-Re;      switch(ir,{Re1  <- X},  {Re2  <- X},  {Re3  <- X},  {Re4  <- X});

}#ir##Parameter loop ################################################################



##########
#FIGURES
##########
#Plotted variables - is=11 represents is=11:14
X<-T;       switch(is-10,{Ts1114  <- X});
X<-P;       switch(is-10,{Ps1114  <- X});
X<-x1;      switch(is-10,{tTP1114 <- X});
X<-TIME;    switch(is-10,{TMs1114 <- X}); #TIME range of BASELINE
X<-WEEKS;   switch(is-10,{WKs1114 <- X});
##Plotting figures
source("FIGS.r")

}#is##Behaviour loop ################################################################


(tb <- tim()-ta) #show time elapsed
##END
