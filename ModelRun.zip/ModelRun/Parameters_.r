#Parameters of Epidemiological model of GIN infection in grazing cattle

#TIME
t0          = 0       #start time, at turnout (days)
tm          = 200     #end time (days)
dt          = 0.1     #time step used for integration (days)

##FL stages
C0          =1        #Egg hatchability-viability
L3c0        =200      #L3 concentration on grass (1/kgDM) at turnout
tdose       =-1       #whether/when L3 Dose given (<0 means is not given)
dose        =if (tdose<0) 0 else 1000 #L3/d - trickle infections
lar3        =dose/dt  #L3/dt intake - trickle infections

##Grass
Nstock      =5        #Stocking density (1/ha)
K           =3500     #Grass carrying capacity density (kgDM/ha)
Area        =1        #Area of pasture available for grazing (ha)
Gm          =K*Area   #Grass DM carrying capacity (kgDM)
rg          =70       #Grass growth per hectare (kgDM/day/ha)
INITGtph    =2500     #Grass DM density at turnout(kgDM/ha)
INITGt      =INITGtph*Area #Grass DM at turnout(kgDM)

##L and Immunity development
nl          =5        #Number of Li development compartments, during L3 establishment
nC          =5        #Number of C development compartments, distributed delay in development on immunity
onl         =1/nl
TmeanL      =32       #Mean pre-patency	(day)
TmeanC      =32       #Mean time of development of C, assumed to be the same as TmeanL
omeanL      =nl/TmeanL#Rate of transition (per compartment)    
omeanC      =nC/TmeanL#Rate of transition (per compartment)    

##Immunity
INITIm      =0.00     #Immunity level at turnout (could be >0 for calves 6-12m old)
Cm          =70000    #Cumulative L3 exposure at 25% of maximum immunity, scale of immunity growth function
oCm         =1/Cm
nI          =3        #Shape parameter growth function describing the level of immunity (Eq. 8)
muC         =log(3)/180 #Rate of loss of host immunity, via decay of the cumulative exposure marker 

##L, W, E - vital parameters controlled by immunity 
est0        =0.6      #Establishment probability of L3 (naive animal)
est1        =0.05     #Establishment probability of L3 (immune host)
muW0        =0.025    #Mortality rate of adult worms (naive host)
muW1        =0.06     #Mortality rate of adult worms (immune host)
f0          =350      #Fecundity rate of worms (naive host)
f1          =30       #Fecundity rate of worms (immune host)
nf          =0.2      #Exponent relating f to immunity level (earlier effect of immunity on f)
nW          =1        #Effect of immunity on mortality rate of adult worms

##W, E parameters
pfem        =0.55     #Proportion of female adult worms
INITW       =0        #Adult worms in host at turnout
INITE       =0        #Cumulative number of eggs produced by adults at turnout
Ws          =15000    #Adult worm scale of density dependence

##Treatment
TREAT       =0        #Flag indicating application of anthelmintic treatment (0=no, 1=yes)
T1          =28       #Time of application of anthelmintic treatment (days after turnout)
T2          =0        #Time of application of second anthelmintic treatment (days), if any (T2<T1 implies there is no 2nd treatment)
Tdrug       =21       #Duration of drug effect in clearing parasitic stages (days)

##BW dynamics
Bg          =1/149    #Rate of host growth or inverse time scale of growth (1/day)
BWm         =700      #Mature body weight of host (kg)
BW0         =200      #Body weight of host at turnout (kg)
cI1         =10       #Rate of biomass used to increase the immunity level (kg/uI)
cI2         =0.4      #Rate of biomass used to maintain acquired immunity kg/uI/d)
cMaint      =0.03     #Rate of biomass used for maintenance functions (kg^0.75/d)
cw          =0        #Rate of biomass used to repair damage per adult worm (likely smaller and less identifiable than immunity-mounting and immunity-maintenance costs)

##FI drop at turnout - factor that multiplies and reduces feed intake, is a function of time since turnout (Eq. S2)   
nout        =1        #Minimum of function (nout=1 means no drop) #Determined by behaviour on turnout
nout        =1        #Minimum of function (nout=1 means no drop) #Determined by BW data
kout        =1/3.04   #Rate parameter (1/day) controlling the bounce back after the minimum is reached
aout        =0.01     #Exponent controlling the sharpness of the drop

##FI dynamics
DDM         =0.8      #Apparent digestibility of DM grass
pFaecesDM   =0.15     #Proportion of DM in faeces
Gcap0       =1        #Scale factor in gut capacity Gcap

##Anorexia induced by the parasite
Expq        =0.8      #Proportion of FI after reduction due to parasite-induced anorexia
lnExpq      =log(Expq)
DWmax       =4000     #Scale (adult worms/day) controlling the nonlinear response A to the change dW/dt in the number of adult worms
oDWmax      =1/DWmax

#Default parameter values after changes
L3c00     = L3c0
Nstock0   = Nstock
T10       = T1
T20       = T2
K0        = K
rg0       = rg

##END